#!/bin/sh
rm ../logisch_1.0*
